	<!-- testimonials -->
	<div class="testimonials py-5" id="testi" style="margin-top: -110px;">
		<div class="container pb-xl-5 pb-lg-3">
			<div class="price-sty position-relative mb-5">
				<h3 class="tittle text-center text-bl mb-2">What Our Client Says</h3>
				<span class="text-style-bot font-weight-bold">T</span>
			</div>
			<div class="row pt-4">
				<div class="col-lg-4 testi-sections mb-4">
					<div class="testimonials_grid">
						<p class="sub-test">Good Place to be in, Clean and good team.</p>
						<div class="row mt-sm-5 mt-4">
							<div class="col-3 testi-img-res text-lg-left text-right">
								<img src="images/te1.jpg" alt="" class="img-fluid" />
							</div>
							<div class="col-7 testi_grid">
								<h5>Ateev </h5>
								<p>Regular Visitor</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 testi-sections mb-4">
					<div class="testimonials_grid">
						<p class="sub-test">Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit. Cras ultricies
							diam sit amet.
						</p>
						<div class="row mt-sm-5 mt-4">
							<div class="col-3 testi-img-res text-lg-left text-right">
								<img src="images/te2.jpg" alt="" class="img-fluid" />
							</div>
							<div class="col-7 testi_grid">
								<h5>Molive Joe</h5>
								<p>Sub heading</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 testi-sections mb-4">
					<div class="testimonials_grid">
						<p class="sub-test">Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit. Cras ultricies
							diam sit amet.
						</p>
						<div class="row mt-sm-5 mt-4">
							<div class="col-3 testi-img-res text-lg-left text-right">
								<img src="images/te3.jpg" alt="" class="img-fluid" />
							</div>
							<div class="col-7 testi_grid">
								<h5>Paige Turner</h5>
								<p>Sub heading</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- //testimonials -->