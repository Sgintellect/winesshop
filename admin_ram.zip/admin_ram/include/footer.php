
 <footer class="footer_wrap widget_area scheme_original" style="z-index: 9999;">
            <div class="footer_wrap_inner widget_area_inner">
                <div class="content_wrap">
                    <div class="columns_wrap">
                        <aside class="column-1_4 widget widget_socials">
                            <div class="widget_inner">
                                <div class="logo">
                                    <a href="index-2.html">
                                        <img src="images\new-logo2.png" class="logo_main" alt="" width="195" height="51">
                                    </a>
                                </div>
                                <div class="logo_descr">Welcome to one of most relaxing salons, where our therapists offer tranquility whilst being treated.</div>
                            </div>

                        </aside>
                        <aside class="column-1_4 widget widget_text">
                            <h5 class="widget_title">Contacts</h5>
                            <div class="textwidget">
                                <ul class="sc_list_style_iconed ">
                                    <li>
                                        <span class="sc_list_icon icon-icon_pin"></span>
                                        1234 Some St San Francisco,<br/>
                                        CA 94102, US 1.800.123.4567
                                    </li>
                                    <li>
                                        <span class="sc_list_icon icon-icon_phone"></span>(123) 456 78 90
                                    </li>
                                    <li>
                                        <span class="sc_list_icon icon-icon_mail"></span>
                                        <a href="#">support@yoursite.com</a>
                                    </li>
                                </ul>
                            </div>
                        </aside>
                        <aside class="column-1_4 widget widget_recent_posts footer-new">
                            <h5 class="widget_title">Recent Post</h5>
                            <article class="post_item no_thumb first">
                                <div class="post_content">
                                    <h6 class="post_title">
                                        <a href="single-post.html">Chiropractic</a>
                                    </h6>
                                    <div class="post_info">
                                        <span class="post_info_item post_info_posted">
                                            <a href="single-post.html" class="post_info_date">March 31, 2016</a>
                                        </span>
                                        <span class="post_info_item ">by
                                            <a href="single-post.html" class="post_info_author">Kate Green</a>
                                        </span>
                                        <span class="post_info_item post_info_counters">
                                            <a href="single-post.html" class="post_counters_item">
                                                <span class="post_counters_number"></span>
                                            </a>
                                        </span>
                                    </div>
                                </div>
                            </article>
                            <article class="post_item no_thumb">
                                <div class="post_content">
                                    <h6 class="post_title">
                                        <a href="single-post.html">Massage Therapy</a>
                                    </h6>
                                    <div class="post_info">
                                        <span class="post_info_item post_info_posted">
                                            <a href="single-post.html" class="post_info_date">March 31, 2016</a>
                                        </span>
                                        <span class="post_info_item ">by
                                            <a href="single-post.html" class="post_info_author">Kate Green</a>
                                        </span>
                                        <span class="post_info_item post_info_counters">
                                            <a href="single-post.html" class="post_counters_item">
                                                <span class="post_counters_number"></span>
                                            </a>
                                        </span>
                                    </div>
                                </div>
                            </article>
                        </aside>
                        <aside class="column-1_4 widget">
                            <ul class="instagram-pics instagram-size-large">
                                <li>
                                    <a href="http://instagram.com/p/BDqPIQOiAb2/" target="_self">
                                        <img src="../scontent-frt3-1.cdninstagram.com/t51.2885-15/s640x640/sh0.08/e35/12677231_253027918375453_1649534054_ne25b.jpg?ig_cache_key=MTIxODg1MzE4NzAzNDI4NTgxNA%3D%3D.2" alt="" title="Instagram Image" />
                                    </a>
                                </li>
                                <li>
                                    <a href="http://instagram.com/p/BDqPG4fCAbs/" target="_self">
                                        <img src="../scontent-frt3-1.cdninstagram.com/t51.2885-15/s640x640/sh0.08/e35/12918633_839382359520640_2147080131_nf4c4.jpg?ig_cache_key=MTIxODg1MzA5MjgyMTgyOTM1Ng%3D%3D.2" alt="" title="Instagram Image" />
                                    </a>
                                </li>
                                <li>
                                    <a href="http://instagram.com/p/BDqPEx2CAbm/" target="_self">
                                        <img src="../scontent-frt3-1.cdninstagram.com/t51.2885-15/s640x640/sh0.08/e35/12912543_796660627134197_1472131256_na5dd.jpg?ig_cache_key=MTIxODg1Mjk0ODI1MjU1OTA3OA%3D%3D.2" alt="" title="Instagram Image" />
                                    </a>
                                </li>
                                <li>
                                    <a href="http://instagram.com/p/BDqPCkuCAbg/" target="_self">
                                        <img src="../scontent-frt3-1.cdninstagram.com/t51.2885-15/s640x640/sh0.08/e35/12912688_1403550456618757_975148170_n139d.jpg?ig_cache_key=MTIxODg1Mjc5NjcyMDc0NDE2MA%3D%3D.2" alt="" title="Instagram Image" />
                                    </a>
                                </li>
                                <li>
                                    <a href="http://instagram.com/p/BDqO_x4CAbY/" target="_self">
                                        <img src="../scontent-frt3-1.cdninstagram.com/t51.2885-15/s640x640/sh0.08/e35/10632417_117727355292967_1787196746_n7d47.jpg?ig_cache_key=MTIxODg1MjYwNDY4ODcyOTgxNg%3D%3D.2" alt="" title="Instagram Image" />
                                    </a>
                                </li>
                                <li>
                                    <a href="http://instagram.com/p/BDqO9VGCAbU/" target="_self">
                                        <img src="../scontent-frt3-1.cdninstagram.com/t51.2885-15/s640x640/sh0.08/e35/925900_1157332147619463_1002029506_n036b.jpg?ig_cache_key=MTIxODg1MjQzNjM0NjE0NDQ2OA%3D%3D.2" alt="" title="Instagram Image" />
                                    </a>
                                </li>
                            </ul>
                        </aside>
                    </div>
                </div>
            </div>
        </footer>

                <div class="copyright_wrap copyright_style_socials scheme_original">
            <div class="copyright_wrap_inner">
                <div class="content_wrap">
                    <div class="sc_socials sc_socials_type_text sc_socials_shape_square sc_socials_size_tiny">
                        <div class="sc_socials_item">
                            <a href="#" target="_blank" class="social_icons social_twitter">twitter</a>
                        </div>
                        <div class="sc_socials_item">
                            <a href="#" target="_blank" class="social_icons social_gplus">gplus</a>
                        </div>
                        <div class="sc_socials_item">
                            <a href="#" target="_blank" class="social_icons social_facebook">facebook</a>
                        </div>
                        <div class="sc_socials_item">
                            <a href="#" target="_blank" class="social_icons social_instagram">instagram</a>
                        </div>
                    </div>
                    <span class="beforeSocials">Connect With Us:</span>
                    <div class="copyright_text">
                        <p> 2016 All Rights Reserved
                            <a href="#" target="_blank">Terms of Use</a> and
                            <a href="#" target="_blank">Privacy Policy</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>


    </div>
