
	<!-- blog -->
	<section class="blog_w3ls py-5" id="blog">
		<div class="container py-xl-5 py-lg-3">
			<div class="price-sty position-relative mb-5">
				<h3 class="tittle text-center text-bl mb-2">Recent Blog</h3>
				<span class="text-style-bot font-weight-bold">B</span>
			</div>
			<div class="row pt-3">
				<!-- blog grid -->
				<div class="col-lg-4 col-md-6">
					<div class="med-blog">
						<div class="blog-header">
							<a href="#">
								<img class="img-fluid" src="images/blog1.jpg" alt="image">
							</a>
						</div>
						<div class="blog-body py-4">
							<span>Feb 12, 2019 - loremipsum</span>
							<a href="#" class="blog-title">Dictum porta auris magna umgtdd fos</a>
							<p>Cras ultricies ligula sed magna dictum portaout auris blandita. Nulla viverra pharetra se.</p>
						</div>
					</div>
				</div>
				<!-- //blog grid -->
				<!-- blog grid -->
				<div class="col-lg-4 col-md-6 mt-md-0 mt-3">
					<div class="med-blog">
						<div class="blog-header">
							<a href="#">
								<img class="img-fluid" src="images/blog2.jpg" alt="image">
							</a>
						</div>
						<div class="blog-body py-4">
							<span>Feb 14, 2019 - pharetra</span>
							<a href="#" class="blog-title">Quis autem vel eum iure reprehdd ende</a>
							<p>Cras ultricies ligula sed magna dictum portaout auris blandita. Nulla viverra pharetra se.</p>
						</div>
					</div>
				</div>
				<!-- //blog grid -->
				<!-- blog grid -->
				<div class="col-lg-4 col-md-6 mx-lg-0 mx-md-auto mt-lg-0 mt-3">
					<div class="med-blog">
						<div class="blog-header">
							<a href="#">
								<img class="img-fluid" src="images/blog3.jpg" alt="image">
							</a>
						</div>
						<div class="blog-body py-4">
							<span>Feb 16, 2019 - portaout</span>
							<a href="#" class="blog-title">Suscipit labo iosam nisi ut aliquid</a>
							<p>Cras ultricies ligula sed magna dictum portaout auris blandita. Nulla viverra pharetra se.</p>
						</div>
					</div>
				</div>
				<!-- //blog grid -->
			</div>
		</div>
	</section>
	<!-- //blog -->