
<script type='text/javascript' src='js/vendor/jquery/jquery.js'></script>
<script type='text/javascript' src='js/vendor/jquery/jquery-migrate.min.js'></script> 
<script type='text/javascript' src='js/vendor/essgrid/lightbox.js'></script>
<script type='text/javascript' src='js/vendor/essgrid/jquery.themepunch.tools.min.js'></script> 
<script type='text/javascript' src='js/vendor/essgrid/jquery.themepunch.essential.min.js'></script>
<script type='text/javascript' src='js/vendor/revslider/jquery.themepunch.revolution.min.js'></script>
<script type="text/javascript" src="js/vendor/revslider/extensions/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="js/vendor/revslider/extensions/revolution.extension.actions.min.js"></script>
<script type="text/javascript" src="js/vendor/revslider/extensions/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="js/vendor/revslider/extensions/revolution.extension.navigation.min.js"></script> 
<script type='text/javascript' src='js/vendor/modernizr.min.js'></script>
<script type='text/javascript' src='js/custom/custom.js'></script>
<script type='text/javascript' src='js/vendor/superfish.js'></script>
<script type='text/javascript' src='js/vendor/jquery.slidemenu.js'></script> 
<script type='text/javascript' src='js/custom/core.utils.js'></script> 
<script type='text/javascript' src='js/custom/core.init.js'></script>
<script type='text/javascript' src='js/custom/theme.init.js'></script>
<script type='text/javascript' src='js/vendor/social-share.js'></script>
<script type='text/javascript' src='js/custom/theme.shortcodes.js'></script>
<script type='text/javascript' src='js/custom/core.messages.js'></script>
<script type='text/javascript' src='js/vendor/hotspot/tooltipster.min.js'></script>
<script type='text/javascript' src='js/vendor/hotspot/script.min.js'></script> 
<!-- <script type='text/javascript' src='js/vendor/grid.layout/grid.layout.min.js'></script> -->
<script type='text/javascript' src='js/vendor/swiper/swiper.js'></script>
    <!-- Include ReadMore -->
    <!-- <script src="dist/readmore.js"></script> -->
<script>
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var moreText1 = document.getElementById("more1");
  

  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
    moreText1.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
</script>

