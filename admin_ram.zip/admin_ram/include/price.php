
	<!-- price -->
	<div class="rooms-w3ls py-5" id="price" style="margin-top: -55px;">
		<div class="container-fluid py-xl-5 py-lg-3">
			<div class="price-sty position-relative mb-5">
				<h3 class="tittle text-center text-bl mb-2">Pricing Plan</h3>
				<span class="text-style-bot font-weight-bold">P</span>
			</div>
			<div class="row pt-sm-4">
				<div class="col-xl-3 col-sm-6">
					<div class="price-w3ls-bottom">
						<div class="lm-item-price text-center">
							<h4 class="my-2"><a href="single.html">Start</a></h4>
							<h6>
								<span class="price-top-head">$</span>
								<span class="price-midd-head">45</span>
								<span class="price-right-head">/ per month</span>
							</h6>
						</div>
						<div class="bot-bg-clrs">
							<ul class="style-lists">
								<li><span class="fa fa-check-circle"></span>Lorem ipsum dolor sit amet</li>
								<li><span class="fa fa-check-circle"></span>consectetur adipiscing elit</li>
								<li><span class="fa fa-check-circle"></span>Aliquam vehicula fringilla</li>
								<li><span class="fa fa-check-circle"></span>Donec eros nisl</li>
							</ul>
							<div class="text-center">
								<a href="#" class="btn button-style-3 mt-sm-5 mt-4">Book Now</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-3 col-sm-6 mt-5">
					<div class="price-w3ls-bottom">
						<div class="lm-item-price grid-2bg text-center">
							<h4 class="my-2"><a href="single.html">Basic</a></h4>
							<h6>
								<span class="price-top-head">$</span>
								<span class="price-midd-head">85</span>
								<span class="price-right-head">/ per month</span>
							</h6>
						</div>
						<div class="bot-bg-clrs">
							<ul class="style-lists">
								<li><span class="fa fa-check-circle"></span>Lorem ipsum dolor sit amet</li>
								<li><span class="fa fa-check-circle"></span>consectetur adipiscing elit</li>
								<li><span class="fa fa-check-circle"></span>Aliquam vehicula fringilla</li>
								<li><span class="fa fa-check-circle"></span>Donec eros nisl</li>
							</ul>
							<div class="text-center">
								<a href="#" class="btn button-style-3 mt-sm-5 mt-4">Book Now</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-3 col-sm-6 mt-sm-0 mt-5">
					<div class="price-w3ls-bottom">
						<div class="lm-item-price grid-3bg text-center">
							<h4 class="my-2"><a href="single.html">Pro</a></h4>
							<h6>
								<span class="price-top-head">$</span>
								<span class="price-midd-head">120</span>
								<span class="price-right-head">/ per month</span>
							</h6>
						</div>
						<div class="bot-bg-clrs">
							<ul class="style-lists">
								<li><span class="fa fa-check-circle"></span>Lorem ipsum dolor sit amet</li>
								<li><span class="fa fa-check-circle"></span>consectetur adipiscing elit</li>
								<li><span class="fa fa-check-circle"></span>Aliquam vehicula fringilla</li>
								<li><span class="fa fa-check-circle"></span>Donec eros nisl</li>
							</ul>
							<div class="text-center">
								<a href="#" class="btn button-style-3 mt-sm-5 mt-4">Book Now</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-3 col-sm-6 mt-5">
					<div class="price-w3ls-bottom">
						<div class="lm-item-price grid-4bg text-center">
							<h4 class="my-2"><a href="single.html">Gold</a></h4>
							<h6>
								<span class="price-top-head">$</span>
								<span class="price-midd-head">195</span>
								<span class="price-right-head">/ per month</span>
							</h6>
						</div>
						<div class="bot-bg-clrs">
							<ul class="style-lists">
								<li><span class="fa fa-check-circle"></span>Lorem ipsum dolor sit amet</li>
								<li><span class="fa fa-check-circle"></span>consectetur adipiscing elit</li>
								<li><span class="fa fa-check-circle"></span>Aliquam vehicula fringilla</li>
								<li><span class="fa fa-check-circle"></span>Donec eros nisl</li>
							</ul>
							<div class="text-center">
								<a href="#" class="btn button-style-3 mt-sm-5 mt-4">Book Now</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- //price -->

