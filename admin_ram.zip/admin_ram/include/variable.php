<?php
$tbl_admin='tbl_admin';
$tbl_category='tbl_category';
$tbl_subcategory='tbl_subcategory';

$tbl_user='tbl_user';
$tbl_setting='tbl_setting';
$tbl_enquiry='tbl_enquiry';
$tbl_service='tbl_service';
$product_new = 'product_new';

$tbl_appointment = 'tbl_appointment';
$tbl_setting     =  'tbl_setting';
$tbl_payment     = 'tbl_payment';
$tbl_frenchise   = 'tbl_frenchise';
ini_set("date.timezone","Asia/Calcutta");
?>