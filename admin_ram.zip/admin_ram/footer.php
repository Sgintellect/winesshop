  <footer class="main-footer">


    <strong>Copyright ©2020-21 Wine Shop. Design by <a href="https://migratech.in/" target="_new">Migratech Softwares</a></strong> All rights reserved.
  </footer>